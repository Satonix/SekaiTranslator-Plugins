from sekai_translator.plugins.types.visual import VisualPlugin
from sekai_translator.plugins.visual_types import TextStyle


class Plugin(VisualPlugin):
    id = "nomes_coloridos"
    name = "Nomes Coloridos"
    version = "1.1.0"

    def __init__(self):
        self.colors = {}
        self.context = None

    def apply(self, context):
        self.context = context
        project = context.current_project
        if project:
            self.load_colors(project)

    # suporte ao gutter
    def gutter_style(self, entry):
        speaker = entry.context.get("speaker")
        if not speaker:
            return None

        color = self.colors.get(speaker)
        if not color:
            return None

        return TextStyle(color=color, bold=True)

    # Hooks
    def style_table_cell(self, entry, column: str):
        speaker = entry.context.get("speaker")
        if column == "speaker" and speaker in self.colors:
            return TextStyle(color=self.colors[speaker], bold=True)
        return None

    def style_original_text(self, entry):
        speaker = entry.context.get("speaker")
        if speaker in self.colors:
            return TextStyle(color=self.colors[speaker])
        return None

    def style_translation_text(self, entry):
        speaker = entry.context.get("speaker")
        if speaker in self.colors:
            return TextStyle(color=self.colors[speaker])
        return None
