from pathlib import Path
import json

from sekai_translator.plugins.types.visual import VisualPlugin
from sekai_translator.plugins.visual_types import TextStyle


class Plugin(VisualPlugin):
    id = "nomes_coloridos"
    name = "Nomes Coloridos"
    version = "1.1.0"

    # versão interna dos dados persistidos
    __data_version__ = 2

    def __init__(self):
        self.colors: dict[str, str] = {}
        self.context = None

    # Lifecycle
    def apply(self, context):
        """
        Chamado quando o plugin é ativado.
        """
        self.context = context

        project = context.current_project
        if project:
            self.load_colors(Path(project.root_path))

        # força repaint imediato
        context.refresh_visuals()

    def on_unload(self, context):
        self.colors.clear()
        context.refresh_visuals()

    # Visual hooks
    def style_table_cell(self, entry, column: str):
        speaker = entry.context.get("speaker")
        if not speaker:
            return None

        color = self.colors.get(speaker)
        if not color:
            return None

        if column == "speaker":
            return TextStyle(color=color, bold=True)

        return None

    def style_original_text(self, entry):
        return self._style_text(entry)

    def style_translation_text(self, entry):
        return self._style_text(entry)

    def gutter_style(self, entry):
        """
        Estilo do gutter (numeração + personagem).
        """
        speaker = entry.context.get("speaker")
        if not speaker:
            return None

        color = self.colors.get(speaker)
        if not color:
            return None

        return TextStyle(
            color=color,
            bold=True,
        )

    # Helpers
    def _style_text(self, entry):
        speaker = entry.context.get("speaker")
        if not speaker:
            return None

        color = self.colors.get(speaker)
        if not color:
            return None

        return TextStyle(color=color)

    def _config_path(self, project_path: Path) -> Path:
        return (
            project_path
            / ".sekai"
            / "plugins"
            / "nomes_coloridos.json"
        )

    def load_colors(self, project_path: Path):
        """
        Carrega cores do projeto atual.
        """
        path = self._config_path(project_path)
        self.colors.clear()

        if path.exists():
            try:
                data = json.loads(
                    path.read_text(encoding="utf-8")
                )

                # compatibilidade futura
                if isinstance(data, dict):
                    self.colors.update(data)

            except Exception as e:
                print(
                    "[NomesColoridos] erro ao carregar cores:",
                    e
                )

        if self.context:
            self.context.refresh_visuals()

    def save_colors(self, project_path: Path):
        """
        Salva cores no projeto atual.
        """
        path = self._config_path(project_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        path.write_text(
            json.dumps(
                self.colors,
                ensure_ascii=False,
                indent=2
            ),
            encoding="utf-8",
        )

        if self.context:
            self.context.refresh_visuals()

    # Speaker discovery (Config UI)
    def collect_speakers(self, project):
        speakers = set()

        for entries in project.files.values():
            for entry in entries:
                speaker = entry.context.get("speaker")
                if not speaker:
                    continue

                speaker = speaker.strip()

                if speaker.lower() in {
                    "alguém",
                    "voz de alguém",
                    "unknown",
                    "???",
                }:
                    continue

                speakers.add(speaker)

        return sorted(speakers)
